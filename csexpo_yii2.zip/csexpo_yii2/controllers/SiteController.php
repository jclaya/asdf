<?php

namespace app\controllers;

use yii\web\Controller;

class SiteController extends Controller {

    public $layout = 'don_layout';
    public $title = 'CSEXPO';

    
    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }
    public function actionIndex() {
        return $this->render('index');
    }
}
