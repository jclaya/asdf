<?php

namespace app\controllers;

use Yii;
use app\models\Registrant;
use app\models\RegistrationForm;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

use yii\filters\AccessControl;

use app\models\LoginForm;

/**
 * HiddenController implements the CRUD actions for Registrant model.
 */
class HiddenController extends Controller
{

    public $layout = 'main';    
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],

            'access' => [
                'class' => AccessControl::className(),  
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['login'],
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'actions' => ['logout', 'register', 'index', 'update', 'delete', 'view', 'error', 'email'],
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function actionConfirm($id, $key)
{//https://gurututorial.wordpress.com/2016/01/10/yii2-signup-with-email-confirmation/
$user = \common\models\User::find()->where([
'‘id’'=>$id,
'‘auth_key’'=>$key,
'‘status’'=>0,
])->one();
if(!empty($user)){
$user->status=10;
$user->save();
Yii::$app->getSession()->setFlash('‘success’','’Success','!’');
}
else{
Yii::$app->getSession()->setFlash('‘warning’','’Failed','!’');
}
return $this->goHome()  ;
}
    public function actionEmail()
    {   
        return $this->render('email');
    }
    /**
     * Lists all Registrant models.
     * @return mixed
     */
    public function actionIndex()
    {   
        $dataProvider = new ActiveDataProvider([
            'query' => Registrant::find(),
        ]);

        return $this->render('index', [
            'dataProvider' => $dataProvider,
        ]);
    }
    
    /**
     * Displays a single Registrant model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Registrant model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Registrant();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Registrant model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Registrant model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Registrant model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Registrant the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Registrant::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionRegister() {
        $model = new Registrant();
        if ($model->load(Yii::$app->request->post()) && $model->save(false)) {
            
            //return $this->redirect(['view', 'id' => $model->id]);
            return $this->render('result', [
                'sql' => 'asdf',
            ]);
        
        }

        return $this->render('register', [
            'model' => $model,
        ]);
    }

    public function actionLogin() {
        if (!Yii::$app->user->isGuest) {
            return $this->actionIndex();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->actionIndex();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }
    public function actionLogout() {
        Yii::$app->user->logout();

        return $this->actionIndex();
    }
}
