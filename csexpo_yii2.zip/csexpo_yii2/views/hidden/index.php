<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Registrants';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="registrant-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'first_name',
            'last_name',
            'student_number',
            'email:email',
            'email_verify_code:email',
            'course',
            'year_level',
            'registered_at',
            'email_verified:email',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
