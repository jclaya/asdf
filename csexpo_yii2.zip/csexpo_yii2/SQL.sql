create table participant();

create table Registrant (
    id int not null primary key auto_increment,
    first_name varchar(64) not null,
    last_name varchar(64) not null,
    student_number int unique,
    email varchar(64) not null unique,
    email_verify_code varchar(64) not null,
    course varchar(20),
    year_level int,
    registered_at int not null,
    email_verified smallint not null default 0
);



create table Presenter (
    id
    team_name
    score_1
    score_2
    score_3
    overall_score
);

create table User(
    id int auto_increment primary key not null, 
    username varchar(255) not null unique, 
    password varchar(255) not null, 
    auth_key varchar(255) not null,
    access_token varchar(255) default null
);  