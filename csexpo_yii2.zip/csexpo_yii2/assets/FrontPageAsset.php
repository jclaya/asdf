<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\assets;

use yii\web\AssetBundle;

class FrontPageAsset extends AssetBundle
{
    public $sourcePath = '@app/assets/app';
    public $css = [
        'css/style.css',
        'css/materialize.min.css',
    ];
    public $js = [
        'js/particle.min.js',
        'js/app.js',
        'js/homepage.js',
        'js/jquery-3.3.1.min.js',
        'js/materialize.min.js',
        'js/stats.min.js',
    ];
}
