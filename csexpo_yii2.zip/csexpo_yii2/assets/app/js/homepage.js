window.onload = function(){
    let $eyes = $('.eye');
    let $tmrw = $('#tmrw');
    let $body = $('#body');
    let $hp = $('#home_page');
    let $white = $('.white');
    let $container = $('.con');
    let $title = $('#title');
    let $particlejs = $('#particles-js');
    $tmrw.hide();
    $particlejs.hide();
    setTimeout(function() {
        $tmrw.fadeIn(3000);
    }, 1000);
    setTimeout(function() {
        $eyes.addClass('start-blinking');
    }, 5000);
    setTimeout(function() {
        $white.addClass('start-lightning');
    }, 7250);
    setTimeout(function() {
        $eyes.hide();
        $tmrw.attr('src', './images/logo1.png');
        $tmrw.attr('alt', 'logo.jpg');
        $tmrw.css('width', '480px');
        $tmrw.css('height', '480px');
        $body.css('background-color', '#fff');
        $body.css('overflow-y', 'visible');
        $container.css('margin-top', '-240px');
        $container.css('margin-left', '-240px');
        $particlejs.show();
    }, 7750);
};