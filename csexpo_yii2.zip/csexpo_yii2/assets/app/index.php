<?php $base_url = 'https://csexpo.tech'; ?>

<!doctype html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0" />
		<title id="title">CSEXPO 2k18</title>
		<link rel="shortcut icon" href="<?= $base_url ?>/images/logo1.png" type="image/png" />
		<link rel="stylesheet" href="<?= $base_url ?>/css/style.css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" />
	</head>
	<body id="body">
<?php
// no specific page defined; resorting to the main page
if(!isset($_GET['page'])) {
?>
		<div class="container">
			<div class="row">
				<div class="col s12">
					<div id="home_page">
						<div class="white"></div>
						<div id="particles-js"></div>
						<div class="con">
							<img id="tmrw" src="<?= $base_url ?>/images/tmrw.png" alt="tmrw.png" />
							<div class="eyes">
								<div id="left" class="eye"></div>
								<div id="right" class="eye"></div>
								<div id="middle" class="circle"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script src="<?= $base_url ?>/js/particle.min.js"></script>
		<script src="<?= $base_url ?>/js/app.js"></script>
		<script src="<?= $base_url ?>/js/homepage.js"></script>
<?php
}
else
{
	switch($_GET['page'])
	{
		// load registration page
		case 'registration':
?>
		<h1>Registration</h1>
<?php
			break;
		
		// no such page found
		case 'not-found':
?>
		<h1>Page not found</h1>
<?php
			break;
			
		default:
			header('Location: ' . $base_url . '/not-found/');
			break;
	}
}
?>
		
		<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
	</body>
</html>
