<?php
namespace app\models;

use yii\base\Model;
use Yii;

/**
 * Signup form
 */
class RegistrationForm extends Model
{
    public $first_name;
    public $last_name;
    public $student_number;
    public $email;
    public $email_verify_code;
    public $course;
    public $year_level;
    public $registered_at;

    /**
     * @inheritdoc
     */
    /*
    public function rules()
    {
        return [
            ['username', 'filter', 'filter' => 'trim'],
            ['username', 'required'],
            ['username', 'unique', 'targetClass' => User::class, 'message' => Yii::t('app', 'This username has already been taken.')],
            ['username', 'string', 'min' => 2, 'max' => 255],

            ['email', 'filter', 'filter' => 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'unique', 'targetClass' => User::class, 'message' => Yii::t('app', 'This email address has already been taken.')],

            ['password', 'required'],
            ['password', 'string', 'min' => 6],
        ];
    }
    

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'student_number' => 'Student Number',
            'email' => 'Email',
            'course' => 'Course',
            'year_level' => 'Year Level',
            'email_verify_code' => 'Email Verify Code',
            'registered_at' => 'Registered At',
            'email_verified' => 'Email Verified ',
        ];
    }
    */
    public function rules()
    {
        return [
            [['first_name', 'last_name', 'email', 'email_verify_code', 'registered_at'], 'required'],
            [['student_number', 'year_level', 'registered_at'], 'integer'],
            [['first_name', 'last_name', 'email', 'email_verify_code'], 'string', 'max' => 64],
            [['course'], 'string', 'max' => 20],
            [['email'], 'unique'],
            [['student_number'], 'unique'],
            
        ];
    }
    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function register()
    {
        if ($this->validate()) {
            $model = new Registrant();
            $model->loadDefaultValues();
            
            $model->first_name = $this->first_name;
            $model->last_name = $this->last_name;
            $model->student_number = $this->student_number;
            $model->email = $this->email;
            $model->course = $this->course;
            $model->year_level = $this->year_level;
            $model->email_verify_code = 'asdf';
            $model->registered_at = 1;
            $model->email_verified = 0;
            $model->save(false);
            return $model->save()->rawSql;
        }

        return null;
    }
}
