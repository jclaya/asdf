<?php

namespace app\models;

use Yii;
use yii\web\IdentityInterface;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $password
 * @property string $auth_key
 * @property string $access_token
 */
class User extends \yii\db\ActiveRecord implements IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password',], 'required'],
            [['username', 'password', 'auth_key', 'access_token'], 'string', 'max' => 255],
            [['username'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'access_token' => 'Access Token',
        ];
    }

    public static function findIdentity($id) {
        return static::findOne(['id' => $id,]);
    }
    public static function findIdentityByAccessToken($token, $type = null) {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    } 
    public static function findByUsername($username) {
        return static::findOne(['username' => $username]);
    }

    public function getId() {
        return $this->getPrimaryKey();
    } 
    public function getAuthKey() {
        return $this->auth_key;
    } 
    public function validateAuthKey($authKey) {
        return $this->getAuthKey() === $authKey;
    } 
    public function validatePassword($password) {
        return Yii::$app->security->validatePassword($password, $this->password);
    } 
    public function setPassword($password) {
        $this->password = Yii::$app->security->generatePasswordHash($password);
    } 
    public function generateAuthKey() {
        $this->auth_key = Yii::$app->security->generateRandomString();
    } 
    public function generatePasswordResetToken() {
        $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
    } 
    public function removePasswordResetToken() {
        $this->password_reset_token = null;
    }
    

}
