<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "registrant".
 *
 * @property int $id
 * @property string $first_name
 * @property string $last_name
 * @property int $student_number
 * @property string $email
 * @property string $email_verify_code
 * @property string $course
 * @property int $year_level
 * @property int $registered_at
 * @property int $email_verified
 */
class Registrant extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'registrant';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['first_name', 'last_name', 'email', 'email_verify_code', 'registered_at'], 'required'],
            [['student_number', 'year_level', 'registered_at', 'email_verified'], 'integer'],
            [['first_name', 'last_name', 'email', 'email_verify_code'], 'string', 'max' => 64],
            [['course'], 'string', 'max' => 20],
            [['email'], 'unique', ],
            ['email', 'email'],

            [['student_number'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'student_number' => 'Student Number',
            'email' => 'Email',
            'email_verify_code' => 'Email Verify Code',
            'course' => 'Course',
            'year_level' => 'Year Level',
            'registered_at' => 'Registered At',
            'email_verified' => 'Email Verified',
        ];
    }
  
    public function beforeSave($insert){
        if (parent::beforeSave($insert)) {
            $this->email_verify_code = 'adsf';
            $this->registered_at = 1;
            return parent::beforeSave($insert);
        } else {
            return false;
        }
    }
}
