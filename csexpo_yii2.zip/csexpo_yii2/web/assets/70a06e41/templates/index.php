<?php
    include('conn.php');
    header('Location: ' . $base_url);
?>
